DB_URI = 'sqlite:///warehouse.db'
SECRET_KEY = 'your_secret_key_here'
